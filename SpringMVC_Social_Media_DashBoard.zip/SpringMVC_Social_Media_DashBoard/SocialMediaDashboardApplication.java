package com.Main.Social_Media_Dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialMediaDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialMediaDashboardApplication.class, args);
	}

}
